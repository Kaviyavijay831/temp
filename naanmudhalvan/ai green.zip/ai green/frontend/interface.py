def get_user_input():
    appliances = []
    print("Enter appliance data (type 'done' to finish):")
    while True:
        name = input("Appliance name: ")
        if name.lower() == "done":
            break
        try:
            power = float(input("Power (in Watts): "))
            hours = float(input("Hours used per day: "))
        except ValueError:
            print("Invalid input. Please enter numbers for power and hours.")
            continue
        appliances.append({"name": name, "power": power, "hours": hours})
    return appliances

def display_results(total_energy, recommendations):
    print(f"\n🔋 Total Energy Consumption: {total_energy} kWh/day")
    print("\n💡 GPT-4 Energy Optimization Tips:\n")
    print(recommendations)
