def calculate_energy_consumption(appliance_data):
    total_energy = 0
    for appliance in appliance_data:
        # Energy (kWh) = Power (kW) × Time (h)
        total_energy += (appliance["power"] / 1000) * appliance["hours"]
    return round(total_energy, 2)
