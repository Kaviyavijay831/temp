import sys
import os
sys.path.append(os.path.dirname(__file__))

from frontend.interface import get_user_input, display_results
from backend.logic import calculate_energy_consumption
from backend.gpt_model import get_gpt_recommendation

def main():
    appliance_data = get_user_input()
    total_energy = calculate_energy_consumption(appliance_data)
    suggestions = get_gpt_recommendation(appliance_data, total_energy)
    display_results(total_energy, suggestions)

if __name__ == "__main__":
    main()
